const config = {
    base_url:'https://geektrust.s3-ap-southeast-1.amazonaws.com/adminui-problem/members.json',
    row_limit :10,
    page_limit:5
}

export default config;